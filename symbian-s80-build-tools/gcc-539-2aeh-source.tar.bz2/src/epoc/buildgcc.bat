@echo off
SET MAKE_MODE=UNIX
SET PATH=c:\cygnus\GNUPRO~1\H-I586~1\bin;c:\cygnus\UNSUPP~1\H-I586~1\bin;%PATH%

REM Basic utilities inc /bin/sh and /etc/termcap

umount /bin
umount /etc
umount /cygnus
mount -b c:\cygnus\UNSUPP~1\H-I586~1\bin /bin
mount -b c:\cygnus\GNUPRO~1\H-i586~1\etc /etc
mount -b c:\cygnus\ /cygnus

if not exist c:\cygnus\UNSUPP~1\H-I586~1\bin\ln.exe_saved copy c:\cygnus\UNSUPP~1\H-I586~1\bin\ln.exe c:\cygnus\UNSUPP~1\H-I586~1\bin\ln.exe_saved
if exist c:\cygnus\UNSUPP~1\H-I586~1\bin\ln.exe_saved copy c:\cygnus\UNSUPP~1\H-I586~1\bin\ln.exe_saved c:\cygnus\UNSUPP~1\H-I586~1\bin\ln.exe

REM Symbian version of Cygnus build environment

mkdir l:\epoc32
mkdir l:\bld_arm\98r2
mkdir l:\bld_thumb\98r2

umount /src
umount /bld_arm
umount /bld_thumb
umount /epoc32
mount l:\epoc32 /epoc32
mount l:\bld_arm\98r2 /bld_arm
mount l:\bld_thumb\98r2 /bld_thumb
mount l:\src /src



ECHO --------------------
ECHO Mounted filesystems:

mount

ECHO -----------------------------------
type l:\src\gcc\version.c
ECHO -----------------------------------
ECHO Now type  build_arm
ECHO -----------------------------------

cd /d l:\src\epoc
bash
