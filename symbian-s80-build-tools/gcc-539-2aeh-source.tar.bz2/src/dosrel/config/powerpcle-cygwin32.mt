DEMODIR=powerpcle-cygwin32

