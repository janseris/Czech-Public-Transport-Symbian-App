DEMODIR=sh-coff-hms
